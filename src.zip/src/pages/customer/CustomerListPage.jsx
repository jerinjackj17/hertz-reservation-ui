import { useEffect, useState } from "react";
import CustomerSearch from "../../components/customer-component/CustomerSearch";
import CustomerTable from "../../components/customer-component/CustomerTable";
import CustomerForm from "../../components/customer-component/CustomerForm";
import {
  getAllCustomers,
  updateCustomer,
  deleteCustomer,
  getCustomerByEmail
} from "../../services/customerApi";

function CustomerListPage() {

  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(false);

  const loadCustomers = async () => {
    const data = await getAllCustomers();
    setCustomers(data);
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const handleSearch = async (email) => {
  if (!email) {
    loadCustomers();
    return;
  }

  try {
    setMessage(null);

    const result = await getCustomerByEmail(email);

    if (!result) {
      setCustomers([]);
      setMessage({
        type: "error",
        text: "No customer found with this email."
      });
      return;
    }

    setCustomers([result]);

  } catch {
    setCustomers([]);
    setMessage({
      type: "error",
      text: "No customer found with this email."
    });
  }
};

  const handleUpdate = async (data) => {
    try {
      setLoading(true);
      setMessage(null);

      await updateCustomer(selectedCustomer.id, data);

      setSelectedCustomer(null);
      await loadCustomers();

      setMessage({
        type: "success",
        text: "Customer updated successfully."
      });

    } catch {
      setMessage({
        type: "error",
        text: "Update failed."
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (email) => {
    try {
      await deleteCustomer(email);
      await loadCustomers();

      setMessage({
        type: "success",
        text: "Customer deleted successfully."
      });

    } catch {
      setMessage({
        type: "error",
        text: "Delete failed."
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto">

      <h1 className="text-3xl font-semibold text-premium-textPrimary mb-8">
        View Customers
      </h1>

      {message && (
        <div
          className={`mb-6 px-4 py-3 rounded-md text-sm ${
            message.type === "success"
              ? "bg-green-50 border border-green-200 text-green-700"
              : "bg-red-50 border border-red-200 text-red-700"
          }`}
        >
          {message.text}
        </div>
      )}

      <div className="mb-8">
        <CustomerSearch onSearch={handleSearch} />
      </div>

      {selectedCustomer && (
        <div className="mb-10">
          <CustomerForm
            selectedCustomer={selectedCustomer}
            onSubmit={handleUpdate}
            clearSelection={() => setSelectedCustomer(null)}
            loading={loading}
          />
        </div>
      )}

      <CustomerTable
        customers={customers}
        onEdit={setSelectedCustomer}
        onDelete={handleDelete}
        loading={loading}
      />

    </div>
  );
}

export default CustomerListPage;